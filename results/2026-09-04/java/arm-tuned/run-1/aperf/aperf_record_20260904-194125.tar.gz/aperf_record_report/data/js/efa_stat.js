processed_efa_stat_data = {"data_name":"efa_stat","data_format":"time_series","runs":{"aperf_record":{"metrics":{},"sorted_metric_names":[]}}}

efa_stat_findings = {"per_run_findings":{}}